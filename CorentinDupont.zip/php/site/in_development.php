<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Corentin Dupont : Page en développement :c</title>
        <link href="../../css/style.css" rel="stylesheet">
    </head>
    <?php 
        include('../../php/site/header.php');
    ?>

    <body>
        <div id="inDevelopment">
            <section>
                <img src="../../images/toonLinkWtfFace.png"/>
                <p>Ouuuups ! ...</p>
                <p>Cette page est en cours de développement :c</p>
                <p>Pour accéder directement au blog, <a href="blog.php">cliquez ici</a></p>
            </section>
        </div>
        
        
    </body>
    
    <?php 
        include('../../html/site/footer.html');
    ?>
</html>